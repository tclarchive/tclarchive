#!/usr/local/bin/perl
# Wiking 1998 <wiking@uniyar.ac.ru>
# CGI-SCRIPT, creating HTML-page of server links, using bot's /links log file (or something alike)
# Version 1.3

# Read instructions in the zw3links.tcl file

# P.S. Email me if this script has appeared useful or has bugs

# This cgi-script url
$url = "http://www.your.server.com/cgi-bin/somewhere/zw3links.pl";

# Location of logfile created by bot
$bot_log = "/somewhere/links.log";

# Physical (not URL) HTML page location if dynamic page creatiin choosen 
# (if this program used as CGI script, it means nothing)  
$html = "/home/logname/www/links.htm";

# The title string of HTML page created
$title = "IRC-servers in the net";

# If you use program for dynamic html file creation only set it to 1
# If cgi+dynamic or cgi set it to 0
$only_dynamic = 0;

# Visual characteristics
# You can change this values if wish
$use_colored = 1;
@sym = (' ', '`-', '|', '+-');
$space_amount = 3;
@color_table = ('000000', '800000', '008000', '000080', '800080', '008080');

#### YOU NEED NOT CORRECT ANYTHING BELOW ####

$bot_l = $ENV{'ZW3'} eq 'ZW3';
if($only_dynamic && !$bot_l) {
  exit;
  } 
if($bot_l) {
  $html_file = $html; # Heh, bot has invoked this scipts, creating HTML-file
} else {
  $html_file = "-"; # for CGI-scripts STDOUT used
  }

# Read log-file
unless(open(FILE, $bot_log)) { exit; }
@file=<FILE>;
close FILE;

# Create @hops, @servs, @descs
foreach $i (@file) {
  next if($i =~ /^\s*#/);
  if($i =~ "^Current: (.*)") {
    $cu = $1;
    next;
    }    
  if($i =~ "^Next: (.*)") {
    $up = $1;
    next;
    }    
  $i =~ s/^\s*\[\d.*?\]\s*//; # delete time-stamp if exists
  $i =~ s/^\s*\[@\]\s*//; # delete [@] if exists
  ($server, $num, $nick, $who, $towhom, $hop, @desc) = split(' ', $i);
  next if($num != 364);
  $server =~ s/://;
  $hop =~ s/://;
  $servs[$n] = $who;
  $to[$n] = $towhom;
  $hops[$n] = $hop;
  $descs[$n] = join(' ', @desc);
  $n++;
  }

&exlusive;
$gn = $ch = 0;
$vrem = $ENV{'QUERY_STRING'};
($hub_server, $type) = split('&', $vrem);
if($bot_l || $vrem eq "") { $type = "color"; }
&correct($hub_server);
&hops0;
&order;
$n = $gn;

# Output
unless(open(FILE, ">$html_file")) { exit; }
if($html_file eq "-") {
  print FILE "Content-type: text/html\n\n"; 
  }
print FILE "<!-- Created by Wiking's script -->\n";
print FILE "<HTML><HEAD><TITLE>$title</TITLE></HEAD>\n";
print FILE "<BODY TEXT=\"#000000\" BGCOLOR=\"#C0C0C0\" LINK=\"#0000FF\" VLINK=\"#800080\" ALINK=\"#FF0000\">\n";
print FILE "<CENTER><H1>$title</H1></CENTER>\n";
if(!$only_dynamic) {
  if($type ne "color") {
    print FILE "<CENTER><A HREF=\"$url?$hub_server&color\">Show layout page</A></CENTER>";
  } else {
    print FILE "<CENTER><A HREF=\"$url?$hub_server&links\">Show referenced page</A></CENTER>";   
    }
  }  
print FILE "<PRE>\n";
for($i = 0; $i < @hops; $i++) {
  $h = $hops[$i];
  for($j = 1; $j <= $h; $j++) {
    print FILE $sym[0] x ($space_amount - 1);
    $z = 0;
    if($j == $h) { $z += 1; }
    if(&is_son($j, $i + 1)) { $z += 2; }
    print FILE $sym[$z];
    }
  $av += $h / (@hops - 1) if(@hops > 1);
  if($type eq "color") {
    if($use_colored) {
      print FILE "<FONT COLOR=#$color_table[$h % @color_table]><B>$servs[$i]</B></FONT>";
    } else {
      print FILE "<B>$servs[$i]</B>";
      }
  } else {
    if(!$i) {
      print FILE "<B>$servs[$i]</B>";
    } else {
      print FILE "<A HREF=\"$url?$servs[$i]\">$servs[$i]</A>";
      }
    }
  print FILE " ($h): <I>$descs[$i]</I>\n";
  }
$av = "Non" if(!$av);
$s = @servs;
printf FILE ("\nAverage hops: %.2f, Servers: %d\n", $av, $s);

print FILE "Document updated: $cu\n" if(defined $cu);
print FILE "Next updating assumed: $up\n" if(defined $up);
print FILE "</PRE>\n";
print FILE "<CENTER><A HREF=\"mailto:wiking\@uniyar.ac.ru\">Wiking 1998</A></CENTER>\n";
print FILE "</BODY></HTML>\n";
close FILE;
exit;


######################
# Auxiliary function #
######################
sub is_son { # hop, level
  my ($hop, $lev) = (@_[0], @_[1]);
  my $i;
  for($i = $lev; $i < @hops; $i++) {
    if($hops[$i] < $hop) { return 0; }
    if($hops[$i] == $hop) { return 1; }
    }
  return 0;
  }

sub swaps {
  my($i, $j) = @_;
  my $t;
  if($i != $j) {
    $t = $servs[$i];
    $servs[$i] = $servs[$j];
    $servs[$j] = $t;
    $t = $to[$i];
    $to[$i] = $to[$j];
    $to[$j] = $t;
    $t = $descs[$i];
    $descs[$i] = $descs[$j];
    $descs[$j] = $t;
    $t = $hops[$i];
    $hops[$i] = $hops[$j];
    $hops[$j] = $t;
    }
  }

sub order {
  my($i, $s);
  $s = $servs[$gn];
  $hops[$gn] = $ch;
  $gn++;
  for($i = $gn; $i < $n; $i++) {
    if($to[$i] eq $s) {
      swaps($gn, $i);
      $ch++;
      &order;
      $ch--;
      if($i < $gn) { 
        $i = $gn - 1; 
        }
      }
    }
  }

sub exlusive {
  my($i, $j, $k);
  for($i = 0; $i < $n; $i++) {
    for($j = $i + 1; $j < $n; $j++) {
      if($servs[$i] eq $servs[$j]) {
        splice(@servs, $j, 1);
        splice(@to, $j, 1);
        splice(@hops, $j, 1);
        splice(@descs, $j, 1);
        $j--;
        $n--;
        }
      } 
    }       
  }

sub hops0 {
  my $i;
  for($i = 0; $i < $n; $i++) {
    if($servs[$i] eq $to[$i]) {
      swaps($i, 0);
      return;
      }
    }
  }

sub correct {
  my ($s, $hub) = @_;
  if($s eq "") { return; }
  $hub = $s unless $hub;
  my ($i, $t);
  for($i = 0; $i < $n; $i++) {
    if($servs[$i] eq $s) {
      $t = $to[$i];
      $to[$i] = $hub;
      if($t ne $s) {
        &correct ($t, $s);
        }
      return;
      }
    }
  }
